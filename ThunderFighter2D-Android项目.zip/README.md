# 雷霆战机（2D Android 项目）

这是一个离线运行的竖屏 2D 现代战机小游戏，使用 Android WebView + HTML Canvas 实现，不需要网络权限、不需要 Root。

## 当前玩法
- 手指拖动战机移动，自动机炮
- 自动追踪导弹（有冷却）
- 敌机、敌方子弹、爆炸粒子、护盾/生命值
- 分数、难度随时间提升、Boss 战
- 本地保存最高分
- 暂停、重新开始

## 打包 APK
推荐使用 Android Studio：
1. 安装 Android Studio（包含 Android SDK）。
2. 解压项目并在 Android Studio 中选择 `Open`，打开 `ThunderFighter2D` 文件夹。
3. 等待 Gradle 同步完成；如提示安装 Android SDK 35，请同意安装。
4. 菜单选择 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. APK 通常会生成在 `app/build/outputs/apk/debug/app-debug.apk`。

也可以在已配置 Android SDK、Java 17 和 Gradle 的电脑上，在项目根目录运行：
`gradle assembleDebug`

## 注意
当前交付的是可构建的 Android 项目源码包，不是已签名/真机测试的 APK。首次构建需要联网下载 Android Gradle Plugin 和 SDK 组件。
